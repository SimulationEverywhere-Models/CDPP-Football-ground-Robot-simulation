zoomedout.avi - this video shows the process of football ground simulation from a high angle, here the robots are being simuated in the top left corner of the ground. It seems like tiny, but when we zoom it we can see the robots more clearly. So for it we have next video file zoomedin.avi

zoomedin.avi - this video shows the process of football ground simulation in zoomed in prespective

Here we have not fully screencaped the whole simulation. We have taken the part of it as it would take lots of time for recording and the recorded file would have large memory too.